/*
 * Copyright 2019 The Nakama Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#pragma once

#include <string>
#include <functional>
#include <memory>
#include <vector>
#include <future>
#include <nakama-cpp/NTypes.h>
#include <nakama-cpp/NExport.h>
#include <nakama-cpp/NSessionInterface.h>
#include <nakama-cpp/data/NMatch.h>
#include <nakama-cpp/data/NRpc.h>
#include <nakama-cpp/realtime/NRtClientListenerInterface.h>
#include <nakama-cpp/realtime/NRtTransportInterface.h>
#include <nakama-cpp/realtime/rtdata/NChannel.h>
#include <nakama-cpp/realtime/rtdata/NChannelMessageAck.h>
#include <nakama-cpp/realtime/rtdata/NMatchmakerTicket.h>
#include <nakama-cpp/realtime/rtdata/NUserPresence.h>
#include <nakama-cpp/realtime/rtdata/NStatus.h>
#include <nakama-cpp/NPlatformParams.h>

NAKAMA_NAMESPACE_BEGIN

    using RtErrorCallback = std::function<void(const NRtError&)>;

    struct RtClientParameters
    {
        /// The host address of the server. Defaults to "127.0.0.1".
        std::string host = "127.0.0.1";

        /// The port number of the server.
        /// Default is 7350 for non-SSL connection, 443 for SSL.
        int32_t port = DEFAULT_PORT;

        /// Set connection strings to use the secure mode with the server. Defaults to false.
        /// The server must be configured to make use of this option. With HTTP, GRPC, and WebSockets the server must
        /// be configured with an SSL certificate or use a load balancer which performs SSL termination.
        /// For rUDP you must configure the server to expose it's IP address so it can be bundled within session tokens.
        /// See the server documentation for more information.
        bool ssl = false;

        /// Platform specific parameters
#ifdef DEFAULT_PLATFORM_PARAMS
        NPlatformParameters platformParams = {};
#else
        NPlatformParameters platformParams;
#endif
    };

    enum class NRtClientProtocol
    {
        /// Protobuf binary protocol. It is recommented to use for production
        /// as it's faster and uses less traffic for communication.
        /// Protobuf support is added in nakama server 2.3.0
        Protobuf,

        /// Json is text protocol. Might be useful for analyzing server traffic.
        Json
    };

    /**
     * A real-time client interface to interact with Nakama server.
     */
    class NAKAMA_API NRtClientInterface
    {
    public:
        virtual ~NRtClientInterface() {}

        /**
         * Pumps requests queue in your thread.
         * Call it periodically, each 50 ms is ok.
         */
        virtual void tick() = 0;

        /**
         * Get websocket transport which RtClient uses.
         */
        virtual NRtTransportPtr getTransport() const = 0;

        /**
         * Set events listener
         *
         * @param listener The listener of client events.
         */
        virtual void setListener(NRtClientListenerInterface* listener) = 0;

        /**
         * Set user data.
         *
         * Client just holds this data so you can receive it later when you need it.
         *
         * @param userData The user data.
         */
        virtual void setUserData(void* userData) = 0;

        /**
         * Get user data.
         *
         * @return The user data.
         */
        virtual void* getUserData() const = 0;

        /**
         * Set heartbeat interval in milliseconds. Disconnect event will be
         * detected in at most 2 x interval.
         *
         * Default is 5 seconds.
         *
         * @param interval interval in ms send heartbeats in. Passing opt::nullopt disables heartbeats.
         */
        virtual void setHeartbeatIntervalMs(opt::optional<int> ms) = 0;

        /**
         * Get heartbeat interval in milliseconds.
         *
         * @return heartbeat interval value or opt::nullopt if disabled
         */
        virtual opt::optional<int> getHeartbeatIntervalMs() = 0;

        /**
         * Connect to the server.
         *
         * @param session The session of the user.
         * @param createStatus True if the socket should show the user as online to others.
         * @param protocol Communication protocol. Default is Protobuf.
         */
        virtual void connect(NSessionPtr session, bool createStatus, NRtClientProtocol protocol = NRtClientProtocol::Protobuf) = 0;

        /**
         * Connect to the server.
         *
         * @param session The session of the user.
         * @param createStatus True if the socket should show the user as online to others.
         * @param protocol Communication protocol. Default is Protobuf.
         */
        virtual std::future<void> connectAsync(NSessionPtr session, bool createStatus, NRtClientProtocol protocol = NRtClientProtocol::Protobuf) = 0;

        /**
         * @return True if connecting to server.
         */
        virtual bool isConnecting() const = 0;

        /**
         * @return True if connected to server.
         */
        virtual bool isConnected() const = 0;

        /**
         * Close the connection with the server.
         */
        virtual void disconnect() = 0;

        /**
         * Close the connection with the server.
         */
        virtual std::future<void> disconnectAsync() = 0;

        /**
         * Join a chat channel on the server.
         *
         * @param target The target channel to join.
         * @param type The type of channel to join.
         * @param persistence True if chat messages should be stored.
         * @param hidden True if the user should be hidden on the channel.
         */
        virtual void joinChat(
            const std::string& target,
            NChannelType type,
            const opt::optional<bool>& persistence = opt::nullopt,
            const opt::optional<bool>& hidden = opt::nullopt,
            std::function<void (NChannelPtr)> successCallback = nullptr,
            RtErrorCallback errorCallback = nullptr
        ) = 0;

        /**
         * Leave a chat channel on the server.
         *
         * @param channelId The channel to leave.
         */
        virtual void leaveChat(
            const std::string& channelId,
            std::function<void()> successCallback = nullptr,
            RtErrorCallback errorCallback = nullptr
        ) = 0;

        /**
         * Send a chat message to a channel on the server.
         *
         * @param channelId The channel to send on.
         * @param content The content of the chat message. Must be a JSON object.
         */
        virtual void writeChatMessage(
            const std::string& channelId,
            const std::string& content,
            std::function<void(const NChannelMessageAck&)> successCallback = nullptr,
            RtErrorCallback errorCallback = nullptr
        ) = 0;

        /**
         * Update a chat message to a channel on the server.
         *
         * @param channelId The ID of the chat channel with the message.
         * @param messageId The ID of the message to update.
         * @param content The content update for the message. Must be a JSON object.
         */
        virtual void updateChatMessage(
            const std::string& channelId,
            const std::string& messageId,
            const std::string& content,
            std::function<void(const NChannelMessageAck&)> successCallback = nullptr,
            RtErrorCallback errorCallback = nullptr
        ) = 0;

        /**
         * Remove a chat message from a channel on the server.
         *
         * @param channelId The chat channel with the message.
         * @param messageId The ID of a chat message to remove.
         */
        virtual void removeChatMessage(
            const std::string& channelId,
            const std::string& messageId,
            std::function<void(const NChannelMessageAck&)> successCallback = nullptr,
            RtErrorCallback errorCallback = nullptr
        ) = 0;

        /**
         * Create a multiplayer match on the server.
         */
        virtual void createMatch(
            std::function<void(const NMatch&)> successCallback,
            RtErrorCallback errorCallback = nullptr
        ) = 0;

        /**
         * Join a multiplayer match by ID.
         *
         * @param matchId A match ID.
         */
        virtual void joinMatch(
            const std::string& matchId,
            const NStringMap& metadata,
            std::function<void(const NMatch&)> successCallback,
            RtErrorCallback errorCallback = nullptr
        ) = 0;

        /**
         * Join a multiplayer match with a matchmaker.
         *
         * @param token A matchmaker ticket result object.
         */
        virtual void joinMatchByToken(
            const std::string& token,
            std::function<void(const NMatch&)> successCallback,
            RtErrorCallback errorCallback = nullptr
        ) = 0;

        /**
         * Leave a match on the server.
         *
         * @param matchId The match to leave.
         */
        virtual void leaveMatch(
            const std::string& matchId,
            std::function<void()> successCallback = nullptr,
            RtErrorCallback errorCallback = nullptr
        ) = 0;

        /**
         * Join the matchmaker pool and search for opponents on the server.
         *
         * @param minCount The minimum number of players to compete against.
         * @param maxCount The maximum number of players to compete against.
         * @param query A matchmaker query to search for opponents.
         * @param stringProperties A set of k/v properties to provide in searches.
         * @param numericProperties A set of k/v numeric properties to provide in searches.
         * @param countMultiple An optional multiple of the matched count that must be satisfied.
         */
        virtual void addMatchmaker(
            const opt::optional<int32_t>& minCount = opt::nullopt,
            const opt::optional<int32_t>& maxCount = opt::nullopt,
            const opt::optional<std::string>& query = opt::nullopt,
            const NStringMap& stringProperties = {},
            const NStringDoubleMap& numericProperties = {},
            const opt::optional<int32_t>& countMultiple = opt::nullopt,
            std::function<void(const NMatchmakerTicket&)> successCallback = nullptr,
            RtErrorCallback errorCallback = nullptr
        ) = 0;

        /**
         * Leave the matchmaker pool by ticket.
         *
         * @param ticket The ticket returned by the matchmaker on join. See <c>NMatchmakerTicket.ticket</c>.
         */
        virtual void removeMatchmaker(
            const std::string& ticket,
            std::function<void()> successCallback = nullptr,
            RtErrorCallback errorCallback = nullptr
        ) = 0;

        /**
         * Send a state change to a match on the server.
         *
         * When no presences are supplied the new match state will be sent to all presences.
         *
         * @param matchId The Id of the match.
         * @param opCode An operation code for the match state.
         * @param data The new state to send to the match.
         * @param presences The presences in the match to send the state.
         */
        virtual void sendMatchData(
            const std::string& matchId,
            std::int64_t opCode,
            const NBytes& data,
            const std::vector<NUserPresence>& presences = {}
        ) = 0;

        /**
         * Follow one or more users for status updates.
         *
         * @param userIds The user Ids to follow.
         */
        virtual void followUsers(
            const std::vector<std::string>& userIds,
            std::function<void(const NStatus&)> successCallback = nullptr,
            RtErrorCallback errorCallback = nullptr
        ) = 0;

        /**
         * Unfollow status updates for one or more users.
         *
         * @param userIds The ids of users to unfollow.
         */
        virtual void unfollowUsers(
            const std::vector<std::string>& userIds,
            std::function<void()> successCallback = nullptr,
            RtErrorCallback errorCallback = nullptr
        ) = 0;

        /**
         * Update the user's status online.
         *
         * @param status The new status of the user.
         */
        virtual void updateStatus(
            const std::string& status,
            std::function<void()> successCallback = nullptr,
            RtErrorCallback errorCallback = nullptr
        ) = 0;

        /**
         * Send an RPC message to the server.
         *
         * @param id The ID of the function to execute.
         * @param payload The string content to send to the server.
         */
        virtual void rpc(
            const std::string& id,
            const opt::optional<std::string>& payload = opt::nullopt,
            std::function<void(const NRpc&)> successCallback = nullptr,
            RtErrorCallback errorCallback = nullptr
        ) = 0;

        /**
         * Accept a party member's request to join the party.
         *
         * @param partyId The party ID to accept the join request for.
         * @param presence The presence to accept as a party member.
         */
        virtual void acceptPartyMember(const std::string& partyId, NUserPresence& presence, std::function<void()> successCallback = nullptr, RtErrorCallback errorCallback = nullptr) = 0;

        /**
         * Begin matchmaking as a party.
         * @param partyId Party ID.
         * @param query Filter query used to identify suitable users.
         * @param minCount Minimum total user count to match together.
         * @param maxCount Maximum total user count to match together.
         * @param stringProperties String properties.
         * @param numericProperties Numeric properties.
         * @param countMultiple An optional multiple of the matched count that must be satisfied.
         */
        virtual void addMatchmakerParty(const std::string& partyId, const std::string& query, int32_t minCount, int32_t maxCount,
            const NStringMap& stringProperties = {}, const NStringDoubleMap& numericProperties = {},
            const opt::optional<int32_t>& countMultiple = opt::nullopt,
            std::function<void(const NPartyMatchmakerTicket&)> successCallback = nullptr, RtErrorCallback errorCallback = nullptr) = 0;

        /**
         * End a party, kicking all party members and closing it.
         * @param partyId The ID of the party.
         */
        virtual void closeParty(const std::string& partyId, std::function<void()> successCallback = nullptr, RtErrorCallback errorCallback = nullptr) = 0;

        /**
         * Create a party.
         * @param open Whether or not the party will require join requests to be approved by the party leader.
         * @param maxSize Maximum number of party members.
         */
        virtual void createParty(bool open, int maxSize, std::function<void(const NParty&)> successCallback = nullptr, RtErrorCallback errorCallback = nullptr) = 0;

        /**
         * Join a party.
         * @param partyId Party ID.
         */
        virtual void joinParty(const std::string& partyId, std::function<void()> successCallback = nullptr, RtErrorCallback errorCallback = nullptr) = 0;

        /**
         * Leave the party.
         * @param partyId Party ID.
         */
        virtual void leaveParty(const std::string& partyId, std::function<void()> successCallback = nullptr, RtErrorCallback errorCallback = nullptr) = 0;

        /**
         * Request a list of pending join requests for a party.
         * @param partyId Party ID.
         */
        virtual void listPartyJoinRequests(const std::string& partyId, std::function<void(const NPartyJoinRequest&)> successCallback = nullptr, RtErrorCallback errorCallback = nullptr) = 0;

        /**
         * Promote a new party leader.
         * @param partyId Party ID.
         * @param partyMember The presence of an existing party member to promote as the new leader.
         */
        virtual void promotePartyMember(const std::string& partyId, NUserPresence& partyMember, std::function<void()> successCallback = nullptr, RtErrorCallback errorCallback = nullptr) = 0;

        /**
         * Cancel a party matchmaking process using a ticket.
         * @param partyId Party ID.
         * @param ticket The ticket to cancel.
         */
        virtual void removeMatchmakerParty(const std::string& partyId, const std::string& ticket, std::function<void()> successCallback = nullptr, RtErrorCallback errorCallback = nullptr) = 0;

        /**
         * Kick a party member, or decline a request to join.
         * @param partyId Party ID to remove/reject from.
         * @param presence The presence to remove or reject.
         */
        virtual void removePartyMember(const std::string& partyId, NUserPresence& presence, std::function<void()> successCallback = nullptr, RtErrorCallback errorCallback = nullptr) = 0;

        /**
         * Send data to a party.
         * @param partyId Party ID to send to.
         * @param opCode Op code value.
         * @param data The input data to send from the byte buffer, if any.
         */
        virtual void sendPartyData(const std::string& partyId, long opCode, NBytes& data) = 0;

        /**
         * Join a chat channel on the server.
         *
         * @param target The target channel to join.
         * @param type The type of channel to join.
         * @param persistence True if chat messages should be stored.
         * @param hidden True if the user should be hidden on the channel.
         */
        virtual std::future<NChannelPtr> joinChatAsync(
            const std::string& target,
            NChannelType type,
            const opt::optional<bool>& persistence = opt::nullopt,
            const opt::optional<bool>& hidden = opt::nullopt
        ) = 0;

        /**
         * Leave a chat channel on the server.
         *
         * @param channelId The channel to leave.
         */
        virtual std::future<void> leaveChatAsync(
            const std::string& channelId
        ) = 0;

        /**
         * Send a chat message to a channel on the server.
         *
         * @param channelId The channel to send on.
         * @param content The content of the chat message. Must be a JSON object.
         */
        virtual std::future<NChannelMessageAck> writeChatMessageAsync(
            const std::string& channelId,
            const std::string& content
        ) = 0;

        /**
         * Update a chat message to a channel on the server.
         *
         * @param channelId The ID of the chat channel with the message.
         * @param messageId The ID of the message to update.
         * @param content The content update for the message. Must be a JSON object.
         */
        virtual std::future<NChannelMessageAck> updateChatMessageAsync(
            const std::string& channelId,
            const std::string& messageId,
            const std::string& content
        ) = 0;

        /**
         * Remove a chat message from a channel on the server.
         *
         * @param channelId The chat channel with the message.
         * @param messageId The ID of a chat message to remove.
         */
        virtual std::future<void> removeChatMessageAsync(
            const std::string& channelId,
            const std::string& messageId
        ) = 0;

        /**
         * Create a multiplayer match on the server.
         */
        virtual std::future<NMatch> createMatchAsync() = 0;

        /**
         * Join a multiplayer match by ID.
         *
         * @param matchId A match ID.
         */
        virtual std::future<NMatch> joinMatchAsync(
            const std::string& matchId,
            const NStringMap& metadata
        ) = 0;

        /**
         * Join a multiplayer match with a matchmaker.
         *
         * @param token A matchmaker ticket result object.
         */
        virtual std::future<NMatch> joinMatchByTokenAsync(
            const std::string& token
        ) = 0;

        /**
         * Leave a match on the server.
         *
         * @param matchId The match to leave.
         */
        virtual std::future<void> leaveMatchAsync(
            const std::string& matchId
        ) = 0;

        /**
         * Join the matchmaker pool and search for opponents on the server.
         *
         * @param minCount The minimum number of players to compete against.
         * @param maxCount The maximum number of players to compete against.
         * @param query A matchmaker query to search for opponents.
         * @param stringProperties A set of k/v properties to provide in searches.
         * @param numericProperties A set of k/v numeric properties to provide in searches.
         * @param countMultiple An optional multiple of the matched count that must be satisfied.
         */
        virtual std::future<NMatchmakerTicket> addMatchmakerAsync(
            const opt::optional<int32_t>& minCount = opt::nullopt,
            const opt::optional<int32_t>& maxCount = opt::nullopt,
            const opt::optional<std::string>& query = opt::nullopt,
            const NStringMap& stringProperties = {},
            const NStringDoubleMap& numericProperties = {},
            const opt::optional<int32_t>& countMultiple = opt::nullopt
        ) = 0;

        /**
         * Leave the matchmaker pool by ticket.
         *
         * @param ticket The ticket returned by the matchmaker on join. See <c>NMatchmakerTicket.ticket</c>.
         */
        virtual std::future<void> removeMatchmakerAsync(
            const std::string& ticket
        ) = 0;

        /**
         * Send a state change to a match on the server.
         *
         * When no presences are supplied the new match state will be sent to all presences.
         *
         * @param matchId The Id of the match.
         * @param opCode An operation code for the match state.
         * @param data The new state to send to the match.
         * @param presences The presences in the match to send the state.
         */
        virtual std::future<void> sendMatchDataAsync(
            const std::string& matchId,
            std::int64_t opCode,
            const NBytes& data,
            const std::vector<NUserPresence>& presences = {}
        ) = 0;

        /**
         * Follow one or more users for status updates.
         *
         * @param userIds The user Ids to follow.
         */
        virtual std::future<NStatus> followUsersAsync(
            const std::vector<std::string>& userIds
        ) = 0;

        /**
         * Unfollow status updates for one or more users.
         *
         * @param userIds The ids of users to unfollow.
         */
        virtual std::future<void> unfollowUsersAsync(
            const std::vector<std::string>& userIds
        ) = 0;

        /**
         * Update the user's status online.
         *
         * @param status The new status of the user.
         */
        virtual std::future<void> updateStatusAsync(
            const std::string& status
        ) = 0;

        /**
         * Send an RPC message to the server.
         *
         * @param id The ID of the function to execute.
         * @param payload The string content to send to the server.
         */
        virtual std::future<NRpc> rpcAsync(
            const std::string& id,
            const opt::optional<std::string>& payload = opt::nullopt
        ) = 0;

        /**
         * Accept a party member's request to join the party.
         *
         * @param partyId The party ID to accept the join request for.
         * @param presence The presence to accept as a party member.
         */
        virtual std::future<void> acceptPartyMemberAsync(const std::string& partyId, NUserPresence& presence) = 0;

        /**
         * Begin matchmaking as a party.
         * @param partyId Party ID.
         * @param query Filter query used to identify suitable users.
         * @param minCount Minimum total user count to match together.
         * @param maxCount Maximum total user count to match together.
         * @param stringProperties String properties.
         * @param numericProperties Numeric properties.
         * @param countMultiple An optional multiple of the matched count that must be satisfied.
         */
        virtual std::future<NPartyMatchmakerTicket> addMatchmakerPartyAsync(const std::string& partyId, const std::string& query, int32_t minCount, int32_t maxCount,
            const NStringMap& stringProperties = {}, const NStringDoubleMap& numericProperties = {},
            const opt::optional<int32_t>& countMultiple = opt::nullopt) = 0;

        /**
         * End a party, kicking all party members and closing it.
         * @param partyId The ID of the party.
         */
        virtual std::future<void> closePartyAsync(const std::string& partyId) = 0;

        /**
         * Create a party.
         * @param open Whether or not the party will require join requests to be approved by the party leader.
         * @param maxSize Maximum number of party members.
         */
        virtual std::future<NParty> createPartyAsync(bool open, int maxSize) = 0;

        /**
         * Join a party.
         * @param partyId Party ID.
         */
        virtual std::future<void> joinPartyAsync(const std::string& partyId) = 0;

        /**
         * Leave the party.
         * @param partyId Party ID.
         */
        virtual std::future<void> leavePartyAsync(const std::string& partyId) = 0;

        /**
         * Request a list of pending join requests for a party.
         * @param partyId Party ID.
         */
        virtual std::future<NPartyJoinRequest> listPartyJoinRequestsAsync(const std::string& partyId) = 0;

        /**
         * Promote a new party leader.
         * @param partyId Party ID.
         * @param partyMember The presence of an existing party member to promote as the new leader.
         */
        virtual std::future<void> promotePartyMemberAsync(const std::string& partyId, NUserPresence& partyMember) = 0;

        /**
         * Cancel a party matchmaking process using a ticket.
         * @param partyId Party ID.
         * @param ticket The ticket to cancel.
         */
        virtual std::future<void> removeMatchmakerPartyAsync(const std::string& partyId, const std::string& ticket) = 0;

        /**
         * Kick a party member, or decline a request to join.
         * @param partyId Party ID to remove/reject from.
         * @param presence The presence to remove or reject.
         */
        virtual std::future<void> removePartyMemberAsync(const std::string& partyId, NUserPresence& presence) = 0;

        /**
         * Send data to a party.
         * @param partyId Party ID to send to.
         * @param opCode Op code value.
         * @param data The input data to send from the byte buffer, if any.
         */
        virtual std::future<void> sendPartyDataAsync(const std::string& partyId, long opCode, NBytes& data) = 0;
    };

    using NRtClientPtr = std::shared_ptr<NRtClientInterface>;

NAKAMA_NAMESPACE_END
