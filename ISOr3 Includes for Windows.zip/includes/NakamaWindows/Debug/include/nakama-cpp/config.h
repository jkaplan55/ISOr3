#pragma once

#define optional_CONFIG_SELECT_OPTIONAL optional_OPTIONAL_NONSTD
#define BUILD_HTTP_CURL
#define BUILD_WEBSOCKET_WSLAY
#define BUILD_CURL_IO
